# ____________________________________________________________________________
#
# Show the particle and photon local average energy
#
# _____________________________________________________________________________

# _____________________________________________________________________________
# Importations

import happi
from matplotlib.pyplot import *
import numpy as np
from matplotlib.colors import LogNorm

# ______________________________________________________________________________
# RCparams

rcParams['font.size'] = 15
rcParams['figure.facecolor'] = 'w'
rcParams['xtick.labelsize'] = 15
rcParams['ytick.labelsize'] = 15
rcParams['axes.labelsize'] = 20

rcParams['xtick.major.size'] = 10
rcParams['ytick.major.size'] = 10

rcParams['xtick.minor.size'] = 5
rcParams['ytick.minor.size'] = 5

rcParams['axes.linewidth'] = 1.5

rcParams['xtick.major.width'] = 2
rcParams['ytick.major.width'] = 2

rcParams['xtick.minor.width'] = 1.5
rcParams['ytick.minor.width'] = 1.5

rcParams['interactive'] = True

# ______________________________________________________________________________
# Parameters

# Path to the simulation directory
path = "./"

# Time step for the diagnotics
timestep = 5500

# Read from command line
if len(sys.argv) > 1:
    timestep = int(sys.argv[1])

# ______________________________________________________________________________
# Figure

fig0 = figure(figsize=(16, 4))
gs = GridSpec(13,5)
ax0 = subplot(gs[:,:])

# ______________________________________________________________________________
# Smilei general information

# open Smilei results
S = happi.Open(path, verbose=False)

# Parameters from the simulation
dt = S.namelist.Main.timestep
dx = S.namelist.Main.cell_length[0]
dy = S.namelist.Main.cell_length[1]
simulation_time = S.namelist.Main.simulation_time

# ______________________________________________________________________________
# Electron Diagnostics

PartDiag = S.ParticleBinning(diagNumber=0,timesteps=timestep)

f_density = np.array(PartDiag.getData()[0]).T
x_density = np.array(PartDiag.get()["x"])
y_density = np.array(PartDiag.get()["y"])

PartDiag = S.ParticleBinning(diagNumber=2,timesteps=timestep)

f_chi = np.array(PartDiag.getData()[0]).T
x_chi = np.array(PartDiag.get()["x"])
y_chi = np.array(PartDiag.get()["y"])

f_chi[f_density>0] = f_chi[f_density>0] / f_density[f_density>0]

print("Maximal electron quantum parameter: {}".format(f_chi.max()))

im0 = ax0.pcolormesh(x_chi,y_chi,f_chi,
                    cmap=get_cmap('jet'),
                    shading='none')

# ______________________________________________________________________________
# Figure properties

im0.set_norm(LogNorm())
im0.set_clim([1e-3,1.])
cb0 = colorbar(im0,format='%g',ax=ax0)
ax0.set_xlabel(r'$\omega_r x / c$')
ax0.set_ylabel(r'$\omega_r y / c$')
ax0.set_ylim([y_chi[0],y_chi[-1]])
cb0.set_label(r'$\chi_-$')
t = ax0.set_title(r'Iteration {}'.format(timestep))
t.set_y(1.02)

fig0.tight_layout()

show()
