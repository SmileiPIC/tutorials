# ____________________________________________________________________________
#
# Show the energy balance (time evolution of the kinetic energy)
#
# _____________________________________________________________________________

# _____________________________________________________________________________
# Importations

import happi
from matplotlib.pyplot import *
import numpy as np

# ______________________________________________________________________________
# RCparams

rcParams['figure.facecolor'] = 'w'
rcParams['font.size'] = 20
rcParams['xtick.labelsize'] = 20
rcParams['ytick.labelsize'] = 20
rcParams['axes.labelsize'] = 25

rcParams['xtick.major.size'] = 10
rcParams['ytick.major.size'] = 10

rcParams['xtick.minor.size'] = 5
rcParams['ytick.minor.size'] = 5

rcParams['axes.linewidth'] = 1.5

rcParams['xtick.major.width'] = 2
rcParams['ytick.major.width'] = 2

rcParams['xtick.minor.width'] = 1.5
rcParams['ytick.minor.width'] = 1.5

rcParams['interactive'] = False

# ______________________________________________________________________________
# Parameters

# Path to the simulation directory
path = "./"

# ______________________________________________________________________________
# Smilei general information

# open Smilei results
S = happi.Open(path, verbose=False)

# Parameters
dt = S.namelist.Main.timestep
dx = S.namelist.Main.cell_length[0]
dy = S.namelist.Main.cell_length[1]
simulation_time = S.namelist.Main.simulation_time

print ' Space steps:',dx,dy

# ______________________________________________________________________________
# Figure

fig0 = figure(figsize=(18, 6))
gs = GridSpec(2, 3)
ax0 = subplot(gs[:,:])

# ______________________________________________________________________________
# Scalar diagnostics

times = np.array(S.Scalar("Ukin_electron").get()["times"])

# electron kinetic energy
ukin_electron = np.array(S.Scalar("Ukin_electron").get()["data"])

# Radiated energy wihtout the macro-photons
urad = np.array(S.Scalar("Urad").get()["data"])

ax0.plot(times*dt,ukin_electron,color='b',label="Electron",lw=2)
ax0.plot(times*dt,urad,color='purple',label="Radiation",lw=2)

# ______________________________________________________________________________
# Figure properties

t = ax0.set_title('Energy balance')
ax0.set_xlabel(r'$\omega_r t$')
ax0.set_ylabel(r'$\varepsilon / mc^2$')
ax0.set_xlim([200,360])
#ax0.set_yscale('log')

ax0.legend(loc='best', fontsize=15)

fig0.tight_layout()

show()
